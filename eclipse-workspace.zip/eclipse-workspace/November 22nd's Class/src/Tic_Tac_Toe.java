import java.util.Random;
public class Tic_Tac_Toe {

	static String[][] Board;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 /*
		X X   
		  O
		O X  O

		X X blank blank O blank O x O
		String[]= {"X","X," "," ","O"," ","O","X","O"}
		*/
		Board  = new String[3][3];
		Board[0][0] = "X";
		Board[0][1] = "X";
		Board[0][2] = " ";
		Board[1][0] = " ";
		Board[1][1] = "O";
		Board[1][2] = " ";
		Board[2][0] = "O";
		Board[2][1] = "X";
		Board[2][2] = "O";
		
		Random r = new Random(5);
		
		/*
		for (int i = 0; i<Board.length;i++) { 
			for (int j=0;j<Board[i].length;j++) {
			int number = r.nextInt(3);
			if (number == 0) {Board[i][j]="X";}
			if (number == 1) {Board[i][j]="O";}
			if (number == 2) {Board[i][j]=" ";}
			}
		}
		*/
		for (int i = 0; i<Board.length;i++) { 
			for (int j=0;j<Board[i].length;j++) {
			 Board[i][j]=" ";
			}
		}
			
		String player = "X";
		int nummoves = 0;
		while(nummoves <9) {
			int row = r.nextInt(3);
			int col = r.nextInt(3);
			if (Board[row][col].equals(" ")) {
					Board[row][col]= player;		
					nummoves++;
					if (checkWin(player)) {
						System.out.println(player + " won in " + nummoves + " moves");
						break;
					}
					if (player.equals("X")) {
						player ="O";
					} else {
						player ="X";	
					}
			}
			
		}
			 
		
		for (int i = 0; i<Board.length;i++) {
			 // do something in each row i
			for (int j=0;j<Board[i].length;j++) {
				// I am visting every column of row i
				System.out.print (Board[i][j] + " ");
			}
			System.out.println();
		}
		}  
		
		public static boolean checkWin(String p)  {
			// p is a string value holding X or O, which is the player to check
			if(Board[0][0].equals(p) && Board[1][1].equals(p) && Board[2][2].equals(p) ) {
				return true;
			}
			if(Board[0][2].equals(p) && Board[1][1].equals(p) && Board[2][0].equals(p) ) {
				return true;
			}
			for (int i = 0; i<Board.length;i++)  {
				int counter = 0;
				for (int j= 0; j<Board[i].length;j++) {
					if (Board[i][j].equals(p)) {counter++;}
				}
				if(counter==3) {return true;}
			}
			for (int i = 0; i<Board.length;i++)  {
				int counter = 0;
				for (int j= 0; j<Board[i].length;j++) {
					if (Board[j][i].equals(p)) {counter++;}
				}
				if(counter==3) {return true;}
			}
					
			return false;
		}
		
	}