import javax.swing.JOptionPane;
public class Amusement_Park {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 Input - The group of people getting on the ride
		 Reference  - There are 10 seats on the ride. The ride can only hold 1200 pounds. Each kid is assumed to be 50 lbs. Each adult is assumed to be 100 lbs. 
		 Process - Determine when the weight limit is over 1200. 
		 Output - Stop when the 10 seats are filled. 
		 */
		
		/*
		 Steps needed to solve:
		 Input the group of people getting a seat on the ride
		 Know when to say stop when the seats are filled or when the weight limit of 1200 has been reached
		 */
		
		
		int kids = 0;
		int adult = 0;
		
		kids = JOptionPane.showConfirmDialog(null, "Are you a kid & 50 lbs?");
		if (kids == JOptionPane.YES_OPTION) {
			JOptionPane.showMessageDialog(null, "Excellent! You can get on the ride!");
			
		adult = JOptionPane.showConfirmDialog(null, "Are you a adult & 100 lbs?");
		if (adult == JOptionPane.YES_OPTION) {
			JOptionPane.showMessageDialog(null, "Great! You can hop on the ride!");
			
		JOptionPane.showMessageDialog(null, "STOP! The limit of 1200 has been reached. Sorry.");
		}
		}
	{
		}
	}
}


				
				
				
