import javax.swing.JOptionPane;
public class Hosting_Services {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		/*
		 Input - amount owed for a month of hosting services
		 Reference - services cost $100 a month, plus $5 for every GB of bandwidth plus $10 for every 500 MB of storage. 
		 Process - Determine the amount owed for a month of hosting services
		 Output -  The amount of GB of bandwidth and MB for a regular customer. Include the 10% discount for seniors.
		 */
		
		/*
		 Steps needed to solve:
		 Input the amount GB of bandwidth and MB and it's cost.
		 Calculate the cost for a regular customer
		 Output the senior citizen discount of 10%
		 */
		
		int cost;
		double amount_of_GB;
		double amount_of_MB;
		double senior_cost;
		
		JOptionPane.showInputDialog("Are you a regular customer or a senior citizen?");
		amount_of_GB = Integer.parseInt(JOptionPane.showInputDialog("Enter amount of GB used:"));
		amount_of_MB = Integer.parseInt(JOptionPane.showInputDialog("Enter amount of MB used:"));
		
		cost = (int) (amount_of_GB * amount_of_MB);
		JOptionPane.showMessageDialog(null, " A site with " +  amount_of_GB  + " and "  +  amount_of_MB  + " would cost $300 ");
		
	
		senior_cost = (int) ((amount_of_GB * amount_of_MB) * .10);
		JOptionPane.showMessageDialog(null, "You are a senior citizen. Here is your 10% discount." + senior_cost);
		
	
	}

	}


