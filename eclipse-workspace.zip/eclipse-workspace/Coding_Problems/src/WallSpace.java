import javax.swing.JOptionPane;

public class WallSpace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 
		 Input - number of walls
		 Reference - one gallon of paint; 8 hours of labor will be needed. $10 for a can of paint and $18 per hour for labor  
		 Process - Determine how much it will cost to paint the room
		 Output- The amount of money to paint one room
		 */
		
		/*
		 Steps needed to solve:
		 Input the number of walls 
		 Calculate amount of money to paint the one room
		 Input number of paint cans used
		 Input amount of time worked
		 */
		
		
		double number_of_walls;
		double amount_of_money;
		
		number_of_walls = Integer.parseInt(JOptionPane.showInputDialog("Enter number of walls:"));
		amount_of_money = (number_of_walls * 115)* 18;
		JOptionPane.showMessageDialog(null, "The amount of money to paint one room is:" + amount_of_money);
		
		
		
	}

}
