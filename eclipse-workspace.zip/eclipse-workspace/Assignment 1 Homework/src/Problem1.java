
public class Problem1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String feet;
		String meters;
		feet = "16.5 feet is";
		meters = "5.0325 meters";
		
		String conversion = feet + " " + meters;
		System.out.println(conversion);
		

	}

}
