
public class Problem3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String pounds;
		pounds = "55.5 pounds is";
		System.out.println(pounds);
		
		String kilograms;
		kilograms = "25.197 kilograms";
		System.out.println(kilograms);

	}

}
