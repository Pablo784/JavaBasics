
public class Problem2 {

	
	public static void main(String[] args) {
		
		
		String minute;
		minute = "1,000,000,000, minutes is apprpximately";
		System.out.println(minute);
		
		String years;
		years = "1902 years and";
		System.out.println(years);
		
		String days;
		days = "214 days";
		System.out.println(days);
		
	}

	{
		
		
	}	}		
