import javax.swing.JOptionPane;
public class Homework {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int [] freqarrary = new int [60]; 
		
		for (int i = 1; i<=5; i++) {
		
		int students_height = Integer.parseInt(JOptionPane.showInputDialog("Please type in your height in inches:")); 
		
		System.out.println(students_height);
		
		freqarrary[students_height]++;
		
		System.out.println(freqarrary);
		
		

		int [] freqarray = new int [60];
		for (int i2 = 1; i2<-5; i2++) {
		int test_score = Integer.parseInt(JOptionPane.showInputDialog("Enter Your test score"));
		System.out.println(test_score);
		freqarray[test_score]++;
		System.out.println(freqarray);
 		
		
		}
		
			
			}
		}
	

	
	

