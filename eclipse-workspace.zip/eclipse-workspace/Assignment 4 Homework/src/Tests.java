
public class Tests {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	int highestNumber = 0;
	int [] test = {6,3,1,1,1,6,3,7,2,2,2,8,0,0,0};
	for (int j = 0; j < test.length - 3; j++) {
	    for (int k = j + 1; k < test.length - 1; k++) {
	        if (test[j] == test[k] && test[j] == test[k + 1] && test[j] == test[j + 1]&&test[j] > highestNumber) {
	      
	        	highestNumber = test[j];
	           
	        	System.out.print(test[j] + " ");
	        	
	           System.out.println();
	           System.out.println(highestNumber);
	           
	        }
	    }
	     {
	    	
	    }
	     {
	    	
	    }
	}
	
	}
}


	
