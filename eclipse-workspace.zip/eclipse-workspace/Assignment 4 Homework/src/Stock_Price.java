
public class Stock_Price {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  int[] prices = new int[12];
	      int count=0;
	      System.out.println(prices.length);
	      for(int i=0; i<prices.length-1; i++){
	          if(prices[i]>prices[i+1]){
	              count++;
	          }
	      }
	      

	      System.out.println(count);
	    }

	{
}
	}
// I got help for all the problems from a tutor from the CST TUTORING CHANNEL ON SLACK. Credit goes to that tutor.