import java.util.Random;
public class Problem4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr = new int[100];
		Random rand = new Random();
		int max = 50;
		int min = 1;
		for (int i = 0; i < 100; i++) {
		    arr[i] = rand.nextInt((max - min) + 1) + min;
		}

		int[] frequencyArray = new int[5];
		for (int i = 0; i < arr.length; i++) {
		    int count = 1;

		    if (0 < arr[i] && arr[i] < 11) {
		        frequencyArray[0]++;
		    } else if (10 < arr[i] && arr[i] < 21) {
		        frequencyArray[1]++;
		    } else if (20 < arr[i] && arr[i] < 31) {
		        frequencyArray[2]++;
		    } else if (30 < arr[i] && arr[i] < 41) {
		        frequencyArray[3]++;
		    } else if (40 < arr[i] && arr[i] < 51) {
		        frequencyArray[4]++;
		    } else {
		        System.out.println("error");
		    }

		}
		System.out.println("the number of test scores from 1-10 is " + frequencyArray[0]);
		System.out.println("the number of test scores from 11-20 is " + frequencyArray[1]);
		System.out.println("the number of test scores from 21-30 is "  + frequencyArray[2]);
		System.out.println("the number of test scores from 31-40 is " + frequencyArray[3]);
		System.out.println("the number of test scores from 41-50 is " + frequencyArray[4]);
		
			
			
		}

	{
{
		


}
}
}