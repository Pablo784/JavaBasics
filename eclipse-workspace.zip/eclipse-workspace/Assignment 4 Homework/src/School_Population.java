
public class School_Population {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String [][] arr = {{"Year", "School Population"}, {"2000", "5000"}, {"2001", "9494"}, {"2002", "12000"}};
		for (int i=1;i<arr.length; i++){
		    double population = Double.parseDouble(arr[i][1]);
		    if(population%1000==0){
		        	System.out.println(arr[i][0] + ":\t"+arr[i][1]);
		    }
		}
	}
		}
