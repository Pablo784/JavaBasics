import java.util.Random;
public class Test_Scores {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] tests = new int[100];
		Random rand = new Random();
		int max = 100;
		int min = 60;
		for (int i = 0; i <  tests.length; i++) {
		    tests[i] = rand.nextInt((max - min) + 1) + min;
		}
		//System.out.println(prices.length);

		for (int j = 0; j < tests.length - 1; j++) {
		    for (int k = j + 1; k < tests.length - 1; k++) 
		        if (tests[j] == tests[k]) {
		            tests[k] = 0;
		        }
		    }

		    System.out.print(tests[j] + " ");
		}
	}


