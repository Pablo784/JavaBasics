import javax.swing.JOptionPane;
public class Student_Tuition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	/*
	 Input - The tuition for regular students, in-state students, out-of-state students, students in the regents program, and the discount for veterans
	 Reference - Fall and Spring Semesters are $5000. Winter is $3000 for in-state students. 
	 For out-of-state students Fall and Spring Semesters are $8000. 
	 Winter is $6000. 
	 Students in the Regents program get a $1000 reduction off their tuition. 
	 Veterans get a 10% discount on the base tuition rate mentioned above.
	 Process - Calculate the tuition for the students in the different categories and apply the discount to the veteran
	 Output - The tuition owed for the semester
	 
	 Steps to solve
	 Calculate the tution for the student depending on what applies to them
	 Give the veterans their 10% discount
	 Output the amount of tution owed depending on the student
	 */
		
		
		int student;
		double fall_and_spring;
		double winter_students;
		double out_of_state_students;
		double winter_out_of_state;
		double regents_program_students;
		double veterans;
		
		student = JOptionPane.showConfirmDialog(null,"Are you a student?");
		if (student == JOptionPane.YES_OPTION) {
		JOptionPane.showMessageDialog(null, "The amount of tution that you owe as a student for the fall & spring semester is $5000");
		
		winter_students = JOptionPane.showConfirmDialog(null, "Are you a in-state student?");
		if (winter_students == JOptionPane.YES_OPTION) {
			JOptionPane.showMessageDialog(null, "The amount of tuition that you owe as a in-state student for the winter semester is $3000");
			
			out_of_state_students = JOptionPane.showConfirmDialog(null, "Are you a out-of-state student?");
			if (out_of_state_students == JOptionPane.YES_OPTION) {
				JOptionPane.showMessageDialog(null, "The amount of tution that you owe as a out-of-state student for the fall & spring semester is $8000");
				
			winter_out_of_state = JOptionPane.showConfirmDialog(null, "Are you a out-of-state student for the winter semester?");
			if (winter_out_of_state == JOptionPane.YES_OPTION) {
				JOptionPane.showMessageDialog(null, "The amount of tuition that you owe as a out-of-state student for the winter semester is $6000");
			
				regents_program_students = JOptionPane.showConfirmDialog(null, "Are you a student part of the regents program?");
				if(regents_program_students == JOptionPane.YES_OPTION) {
					JOptionPane.showMessageDialog(null, "You get a reduction from your tuition of $1000");
					
					veterans = JOptionPane.showConfirmDialog(null,  "Are you a veteran?");
					if (veterans == JOptionPane.YES_OPTION) {
						JOptionPane.showMessageDialog(null, "Since you are a veteran you get a discount of 10%");
						
					}
				}
			}
			}
		}
		
		
		

	}

} 
}
