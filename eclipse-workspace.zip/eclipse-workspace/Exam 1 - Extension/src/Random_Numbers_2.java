import java.util.Random;

public class Random_Numbers_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Random r;
		r = new Random(6);
		int number1,number2;
		number1 = r.nextInt(10);
		number2 = r.nextInt(10);
		
		System.out.println(number1 + "-" + number2); 
		if (number1 >=5 && (number2 >=5) ){
			System.out.println("YOU WIN!!!");
		} else {
			System.out.println("You Lose");
			
			
			double d = (double) 4/7;
			System.out.printf("%10.2f", d);
			d = (double) 42/3;
			System.out.printf("%10.2f", d);
			String message;
			message = String.format("%10.2f", d); {
				}
			}
		
		

	}

}
