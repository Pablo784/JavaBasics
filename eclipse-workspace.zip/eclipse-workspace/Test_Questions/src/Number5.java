import javax.swing.JOptionPane; 
public class Number5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	// The number of people in the family are 4 and each family 
	// member is subtracted $2000. The tax due is 24% after what's left of the income  
		
	// Here are the IRPO Components
		
	// I - Number of Family Members
	// R - Deduction amount: 2000  Tax Rate: .24
	// P - Calculate how much their tax is based off the percentage and give them their total 
	// O - Tax due
		
	// The code I am about to write will consist asking the user if there are 4 members in their family and if that is the case
	// the program will tell them that $2000 will be deducted for tax purposes at 22% and then afterwards it will output how much they 
	// will receive back after deductions
		
	// I got help from a tutor for this. Credit goes to that tutor
	
    double income;
    double amount_of_tax_due;
    int number_of_family_members;

    income = Double.parseDouble(JOptionPane.showInputDialog("Enter amount of tax due:"));
    number_of_family_members = Integer.parseInt(JOptionPane.showInputDialog("Enter number of family members:"));
    //calculate tax due
    amount_of_tax_due = (income - (number_of_family_members*1000))*0.24;
    JOptionPane.showMessageDialog( null, amount_of_tax_due);
    
	}
}


		
		
