import java.util.Scanner;
public class Number8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Grocery items bought 
		// You have $4
		// The program inputs the cost of an item
		// Each item is 1 to 99 cents.
		
	// I - cost of an item
	// R - Total number of items that can be purchased and highest cost of item in the basket that can be bought for $2
	// P - Figure out how many grocery items can be bought 
	// O - The number of items bought, highest cost, a notice that puts you over the limit
		
		
	// The code in which I am about to write will figure out how many grocery items can be bought with just $2. 
	// I will have to figure out a lot of things like how many items can be purchased and the highest cost. 
	// I need to output the total number of items that can be bought with $4 and the highest cost of an item in the basket 
	// that can be bought for $4
		
	
// I got help from a tutor for this. Credit goes to that tutor 	


double grocery_items_cost = 0, total = 0, temp = 0;
int grocery_items_count = 0; // to hold the number of items

Scanner scan = new Scanner(System.in);


//5, 23,42, 53,31, 84
while (total < 200) {

    System.out.print("Enter cost of items (each item is 1 to 99 cents): ");
    grocery_items_cost = Double.parseDouble(scan.nextLine());

    total += grocery_items_cost;

    if (total < 200) {
        if (grocery_items_cost > temp) {
            temp = grocery_items_cost;
        }
        grocery_items_count++;
    }
    //System.out.println(total);


}
//Your program should output the following:
//1) The total number of items that can be bought without going over $3.
System.out.println(grocery_items_count + " items can be bought, highest cost:" + temp + " - notice the " + grocery_items_cost + " puts you over the limit");
//2) The highest cost of an item in the basket that can be bought for under $3.
{
}
}
	{
	}
	}