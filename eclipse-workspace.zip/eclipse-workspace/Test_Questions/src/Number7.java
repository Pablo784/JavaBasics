import java.util.Scanner;
public class Number7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	// How much money do you have?
	// how many quarters, dimes,nickels and pennies are in your change?
	//  All items cost between 1 and 99 cents.
	// The Cost of the 1st item will be 99 cents
	// The Cost of the 2nd item will be 98 cents
		
	// I - Cost of the Items
	// R - Coinage rules (Quarter - .25, Dime - .10, Nickel - .05 , Penny - .01) 
	// P - Calculate how much change you will get back in quarters, dimes, nickels, and pennies
	// O - Display in one line how much your change is and how much that is in quarters, dimes, nickels, and pennies
		
	// The code which I am about to write which was a optional question on the test but now I have to actually do it will 
	// output how much change I will get right down to the penny. It will ask the user for the cost of of the item and then it
	// will give the user it's change and how it is as I said before right down to the penny. 
	
		
	// I got help from a tutor for this. Credit goes to that tutor 
		
		double  change = 0, cost;
		int quarters = 0, dimes = 0, nickels = 0, pennies = 0;

		//for user input
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter Price of the item between 1 and 99 cents: ");
		cost = Double.parseDouble(scan.nextLine());
		change = 100 - cost;
		//cost = Double.parseDouble(JOptionPane.showInputDialog("Enter Price of the item between 1 and 99 cents: "));
		quarters = (int) (change / 25);
		change = change - quarters*25;
		dimes = (int) (change / 10);
		change = change - dimes*10;
		nickels = (int) (change / 5);
		change = change - nickels*5;
		pennies = (int) (change / 1);
		System.out.println("Quaters:  " + quarters + " .Dimes: " + dimes + " .Nickels: " + nickels + "  .Pennies: " + pennies);
	}
	{
	}
	}
