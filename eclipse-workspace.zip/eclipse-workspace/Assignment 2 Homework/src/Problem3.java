import javax.swing.JOptionPane;

public class Problem3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int probability;
		
			probability = Integer.parseInt(JOptionPane.showInputDialog("Enter a number:"));
			
		if (probability==56);
		
		if (probability==23);
		
		
		if (probability==14);
		
		if (probability==45);
			JOptionPane.showMessageDialog(null, "The output is 14");
	
		

	}

}
