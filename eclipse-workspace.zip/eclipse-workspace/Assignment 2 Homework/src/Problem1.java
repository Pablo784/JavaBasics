import javax.swing.JOptionPane;

public class Problem1 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int testscore;
		testscore = Integer.parseInt(JOptionPane.showInputDialog("Enter test score"));
		
		if (testscore==90) {
			JOptionPane.showInputDialog("You got an A!");
			
		if (testscore==80);
			JOptionPane.showInputDialog("You got a B!");
			
			
		if (testscore==70); {
			JOptionPane.showInputDialog("You got a C.");
		
		if (testscore==60); {
			JOptionPane.showInputDialog("You got a D.");	
		if (testscore==0);
			JOptionPane.showInputDialog("You got an F.");
		}
		}
		
		}
		
		
		

	}

}
