import javax.swing.JOptionPane;

public class Problem2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int student;
		student = Integer.parseInt(JOptionPane.showInputDialog("Type in a year:"));
		
	
		
		if (student==2021);
	
			JOptionPane.showInputDialog("You are a Senior");
			
		if (student==2020);
			JOptionPane.showInputDialog("You are a Sophomore");
	
			
		if (student==2019);
			JOptionPane.showInputDialog("You are a Junior");
	 
			
		if (student==2018);
			JOptionPane.showInputDialog("You are a Freshman"); 
			
			{
			} 

			}
				{
				
				}
			}
		
	

