import javax.swing.JOptionPane;

public class MonthSales {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int number;
		int sum = 0;
		String input;
		
		input = JOptionPane.showInputDialog("Enter items sold for month 2");
		int number_of_iterations_ = Integer.parseInt(input);
		
		for (int loopindex = 1; loopindex <= number_of_iterations; loopindex = loopindex + 1) {
			
		input = JOptionPane.showInputDialog("Enter number of month" + loopindex +);
			
		}
		
	}

}
