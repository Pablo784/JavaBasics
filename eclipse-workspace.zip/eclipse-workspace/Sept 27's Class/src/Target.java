import javax.swing.JOptionPane;
public class Target {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* 
		 * imagine a board that 500 by 500 pixels 
		 * the bullseye is 100 by 100 in the middle
		 * What is the x,y, point of the upper left of the bullseye? 200,200
		 * What is the x,y, point of the bottom right of the bullseye? 300,300
		 * top left is 0,0.... top right 500,0
		 * bottom left:  0,500  bottom right: 500,500
		 * Pick a random number for 1-500 for x
		 * Pick a random number from 1-500 for y
		 * x = 259, y = 430 below the target
		 * x = 280, y = 210 ??
		 */

	}
	
	
	int number_of_throws = 1000000;
	int number_of_hits = 0;
	int streak=0;
	int x, y;
	int longest_streak = 0;

	Random r = new Random(31); 
	for (int i = 1; i<=number_of_throws;i++ ) {	
	x = r.nextInt(500) + 1;
	y = r.nextInt(500) +1;
	if (x>=200 && x<=299 && y>=200 && y<=299) {
		streak = streak + 1;
		number_of_hits++;
	} else {
		streak = 0; }
		streak = 0;
	{
		if (streak > longest_streak) {longest_streak=streak;}
	}
	JOptionPane.showMessageDialog(null, (double) number_of_hits/number_of_throws * 100); 
	  
	//JOptionPane.showMessageDialog(null, (double) (100*100)/(500*500)*100); 
	




		