import java.util.Random;
import javax.swing.JOptionPane;


public class RandomNumbers {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Random r;
	r = new Random(20);
	int number1,number2;
	number1 = r.nextInt(10);
	number2 = r.nextInt(10);
	
	System.out.println(number1 + "-" + number2); 
	if (number1 >=5 && (number2 >=5) ){
		System.out.println("YOU WIN!!!");
	} else {
		System.out.println("You Lose");
		
		
		double d = (double) 4/7;
		System.out.printf("%10.2f", d);
		d = (double) 42/3;
		System.out.printf("%10.2f", d);
		String message;
		message = String.format("%10.2f", d); {
			}
		}
			
	int option;
	option = JOptionPane.showConfirmDialog(null, "Is the sun Yellow?");
	if (option == JOptionPane.YES_OPTION) {
		JOptionPane.showMessageDialog(null, "Excellent! you clicked YES.");
	} else {
		if (option == JOptionPane.NO_OPTION) {
			JOptionPane.showMessageDialog(null, "You clicked NO? Thats unfortunate.");
		} else {
			JOptionPane.showMessageDialog(null, "I'll ask you later");
		}
	}
		
	}
}
	

	




