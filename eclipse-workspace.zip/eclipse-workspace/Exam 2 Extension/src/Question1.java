import java.util.Random;
public class Question1 {

	public static void main(String[] args) {
		// Dialog Box Problem
		
		Random r =  new Random(13);
		int numbersinrow = 0;
		int lastnumber = 3;
		int number= 0;
		int picks = 0;
		while (numbersinrow < 3) {
			number = r.nextInt(5)+1;
			System.out.print(number + " ");
			picks++;
			if (number == lastnumber + 1) {
				numbersinrow++;
			} else {
			numbersinrow=1;
				
			}
			lastnumber = number;
			
			}
			System.out.println("\n"+picks);
		

	}

}
