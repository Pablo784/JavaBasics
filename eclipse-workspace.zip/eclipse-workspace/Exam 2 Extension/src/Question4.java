import javax.swing.JOptionPane;

public class Question4 {

	public static void main(String[] args) {
		// Stock Arrays
		
		// I had the layout of the code in my mind but I couldn't type it out for some reason

		String[] stocksymbol = {"MSFT","IBM","GE","FB","AMZN"} ;
		String[] companynames = {"Microsoft","International Business Machines", "General Electric","Facebook","Amazon"};
		double[] stockprices = {330.59,117.10,94.99,324.46,3507.07};
		
		int nameofcomapny;
		int nameofcompany = Integer.parseInt(JOptionPane.showInputDialog("Enter company to get it's stock price:"));
		
	
		
	
		
					
				
		}
		
		
	

{
	}
}