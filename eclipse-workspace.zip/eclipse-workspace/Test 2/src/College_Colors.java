

public class College_Colors {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 String[] colleges = {"Baruch","CityTech","Hunter","Brooklyn","BMCC"};
		 String[] colors = {"Blue","Red","Green","Yellow","Purple"};
		 
		System.out.println();
		System.out.println("Baruch - Blue, CityTech - Red, Hunter - Green, Brooklyn - Yellow, BMCC - Purple");
		
	

	
		
	}  
	
		}

