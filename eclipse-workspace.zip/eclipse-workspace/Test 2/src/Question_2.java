import java.util.Random;
public class Question_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Random r =  new Random(12);
		int numbersinrow = 0;
		int lastnumber = -2;
		int number= 0;
		int picks = 0;
		while (numbersinrow < 3) {
			number = r.nextInt(10)+1;
			System.out.print(number + " ");
			picks++;
			if (number == lastnumber + 1) {
				numbersinrow++;
			} else {
			numbersinrow=1;
				
			}
			lastnumber = number;
			
			}
			System.out.println("\n"+picks);
		}
	
}

// The professor went over this on 11/24