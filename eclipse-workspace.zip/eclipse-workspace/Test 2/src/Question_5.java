import java.util.Random;
public class Question_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Random r = new Random();
		int tests[] = new int [20];
		//populate the array
		for (int i = 0; i<tests.length;i++) {
			
			tests[i] = r.nextInt(21)+ 20;
			
		}
		
		int min = 0;
		int max = 0;

		for (int i = 0; i<tests.length;i++) {
			if(tests[i]<min) {
				min = tests[i];
				
			}
			if(tests[i]>max) {
				max = tests[i];
				
			}
		}
	}

}
// The Professor went over this in class on 11/24