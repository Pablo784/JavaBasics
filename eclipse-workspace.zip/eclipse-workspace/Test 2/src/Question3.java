import java.util.Random;
public class Question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random r = new Random();
		int tests[] = new int[50];
		// populate the array
		for (int i = 0; i<tests.length;i++) {
			tests[i] = r.nextInt(10)+ 1;
		}
		
		for (int i = 0; i<tests.length;i++) {
			if (tests[i]%2==1) {tests[i]=0;}
		}

	}

}
//The professor went over it on 11/24