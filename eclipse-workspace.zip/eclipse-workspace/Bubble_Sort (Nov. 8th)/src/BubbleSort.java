import java.util.Random;

public class BubbleSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr = new int[9];
		int[] dup = new int[9];
		Random r =  new Random(12);
		// populates the array
		int index = 0;
		
		while(index < arr.length) {	
			int number = r.nextInt(9) + 1;
				if (dup[number-1]==0) {
					arr[index]= number;
					index=index+1;
					dup[number-1]=1;
				}
			
		}
		printarray(arr);
		boolean swap=true;
		while(swap) {
			swap=false;
			
		}
		for (int i=0; i<arr.length-1; i++) {
			if (arr[i]> arr[i+1]) {
				// swap i and i+1
				swap=true;
				int temp; 
				temp = arr[i];
				arr[i]=arr[i+1];
				arr[i+1]= temp;
				
			}
		}
		
		printarray(arr);
	}
		
		
	
public static void printarray(int[] inarray) {
	System.out.println(); {
	for (int j=0; j<inarray.length; j++) {
		System.out.print(" " + inarray[j]);
	}
}

	}
	
}
