import java.util.Random;
public class EliminateDups {

	public static void main(String[] args) {
			int number;
			int arr[] =  new int[10];
			Random r = new Random(3);
			for (int index = 0; index<arr.length; index++) {
				number = r.nextInt(9) + 1;
				arr[index] = number;
				
				
			}
		printarray(arr);
		for (int i = 0; i<arr.length; i++) {
			//System.out.println("I am looking at arr index:" + i + "-" + arr[i]);
			for (int j= i+1; j<arr.length; j++) {
				//System.out.println("    " + i + "-" + j + arr[i] + "-" + arr[j]);
				if(arr[i] == arr[j]){
					//System.out.println("SAME");
					arr[j]=0;
					
				}
			
				
		}
			
		}
}
	
	
	
	public static void printarray(int[] inarray) {
		System.out.println();
		for (int j = 0; j<inarray.length; j++)
		System.out.print(" " + inarray[j]); {
			
		}
	}
}