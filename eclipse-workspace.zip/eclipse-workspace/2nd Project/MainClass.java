
public class MainClass {

	public static void main(String[] args) {
		    
		String first;
		String last;
		first = "Pablo";
		last = "Vasquez";
		String fullname = first + " " + last;
		System.out.println("Hello" + "\n" + fullname);
		System.out.println("10\t20\t30\t40");
		System.out.println("He said \"Hi to me\" ");
		
		int fahren;
		fahren = 90;
		fahren = fahren + 12;
		System.out.println(fahren);
		
		double celsius;
		celsius = 32;
		celsius = (fahren - 32) / 5/9;
		System.out.println(celsius);
		
		
		

	}

}
// x = "abc"
// x = 5 