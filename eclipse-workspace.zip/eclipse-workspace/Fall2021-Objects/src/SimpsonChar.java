
public class SimpsonChar {
	private int age;
	private String name;
	private String occupation;
	private String catchphrase;
	private boolean gender; // true for female, false for male
	
	public void setAge(int inage) {
		age = inage;
	}
	public int getAge() {
		return age;
	}
		
	
	
	
	public String getGender(String ingender) {
		if (ingender.equals("F")) {
			return "F";
		} else {
			return "M";
		}
		}
	
	
	public void setGender (String ingender) {
		if (ingender.equals("F")) {
			gender = true;
		} else {
			gender = false;
			
		}
		}
	
	
	//constructor method
	// overloading methods 
	public SimpsonChar(String invalue) {
		name = invalue;
	}
		public SimpsonChar() {
			name = "unknown";	
		
	}
		
 	
	public void sayGreeting(String intro) {
		System.out.println(intro + ": " +  name + " and I like to say: " + catchphrase );
	}
		
		public void sayGreeting() {
			String message = "Hello my";
			System.out.println(message + "name is: " + name + " and I like to say: " + catchphrase );
			
		
	}
	
	
	
}
