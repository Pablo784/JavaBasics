import java.util.Random;

public class SimpsonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Random r;
		r = new Random(4);
		r = new Random();
		int num = r.nextInt(3);
		
		
		SimpsonChar m,b;
		// m is a reference variable
		// instantiation
		m = new SimpsonChar("Marge");
		m.setAge(35);
		m.setGender("U");
		if (m.getAge()>30 && m.getGender().equals("F")) {
			m.setOccupation("Olderwife");
		} else {
			m.setOccupation("Youngerwife");
		}
		// object is an instance of a class
		b = new SimpsonChar();
		b.name = "Bart";
		b.age = 12;
		b.occupation = "Student";
		// encapsulation - call or use a method of another class, and
		// not worry how that class does it
		b.catchphrase = "Ay Caramba!";
		
		m.sayGreeting();
		m.sayGreeting("Hey there I'm cool");
		b.sayGreeting();
		
		GoogleMap g;
		g = new GoogleMap();
		int dist;
		dist = g.getDistance("CityTech", "TimesSquare");
		
		
	}

}
// This is December 6th's class