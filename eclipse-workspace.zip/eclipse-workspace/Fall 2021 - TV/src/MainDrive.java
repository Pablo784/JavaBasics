
public class MainDrive {

	public static void main(String[] args) {
		
		String Guide[] = {"FamilyFeud","Simpsons","Modern Family","Family Guy","Giants Game","South Park","American Dad","Bob's Burgers"};
		
		TV BigTV;
		
		
		BigTV = new TV();
		BigTV.turnOn();
		BigTV.setChannel(5);
		BigTV.ChannelUp();
		System.out.println(BigTV.getChannel());
		TV LeftTV = new TV();
		LeftTV.turnOn();
		LeftTV.setChannel(7);
		TV RightTV = new TV();
		RightTV.turnOn();
		RightTV.ChannelUp();
		RightTV.ChannelUp();
		
		System.out.println[BigTV.getChannel()-1]);
		System.out.println[LeftTV.getChannel()-1]+"\t\t");
		System.out.println[RightTV.getChannel()-1]);
		

	}

}
