
private class TV {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		public class TV {
		private tvvolume;
		private tvchannel;
		private boolean status; // true = tv is on
		
	
		public TV() {
			tvvolume = 0;
			tvchannel = 1;
			status=false;
				
		}
		
		public void turnOff() {
			status = false;
		}
		
		public void turnOn() {
			status=true;
		}
		
		
		public void setChannel(int inchannel) {
				if(status) {
			tvchannel=inchannel;
				}
		
			
		}
			public void ChannelUp() {
				tvchannel=tvchannel + 1;
				
	}
			public int getChannel() {
				tvchannel=tvchannel - 1;
				
			}
			
			public int getChannel() {
				return tvchannel;
			}
			
			
}
	}
}
	

		
		