
public class For_loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* While Loop Code
		 * 
		 * int i = 3, total = 0, sum = 18;

                         while (i > sum) {

                                     total += sum + i;

                                     i = i -1 ;

                         }
		 * 
		*/
		
		int total = 0; sum = 18;
		for (int i = 3; i<sum;) {
			System.out.println(total);
			total = sum + total; 
		}
		
		
		
		

	}

}
