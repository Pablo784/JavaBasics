import javax.swing.JOptionPane; 
public class Car_Size {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] CarModel = {"Volks","wagon","Nova","Hyundi","Jetta","Honda"}
		String[] Size  = {"small","large","small","compact","compact","small"}
		inputsize = JOptionPane.showInputDialog("What is the size of the car?");
		
		for (int i = 0; i<CarModel.equals; i++) {
			if (inputsize.equals(Size[i])) {
				System.out.println(CarModel[i]);
			}
		}
		

	}

}
