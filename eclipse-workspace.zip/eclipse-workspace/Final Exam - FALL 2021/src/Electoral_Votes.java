
public class Electoral_Votes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String States= {"NY","NJ","PA","CT","OH","FL","CA"};

		String ElectoralVotes[] = {26,25,22,14,20,3,45};

		int[] TrumpPopularVotes=[8345866,34432222,4594396,8493823,2243443,1777554,7654544];

		int[] BidenPopularVotes= [9345866,44438282,4990966,7493823,2243443,1777444,97654544];
		
		System.out.println("Biden's electoral votes are" + BidenPopularVotes);
		System.out.println("Trump's electoral votes are" +TrumpPopularVotes)

	}

}
