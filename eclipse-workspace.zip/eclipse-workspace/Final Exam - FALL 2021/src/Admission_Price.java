import javax.swing.JOptionPane; 
public class Admission_Price {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	
		int[] age = {23,25,3,13,56,65,23,12};
		age = Integer.parseInt(JOptionPane.showInputDialog("Enter age to determine admission fee:");
		String price = null;
		
		if (age == 0) {
			price = "FREE!";
			
		if (age == 5 || 18) {
			price = "$20 please";
			
		if (age == 19 || 60) {
			price = "$24 please";
		
		if (age == 60) {
			price = "$3 please";
		}
		
		
		JOptionPane.showMessageDialog(null, "Your age is" + age + "so you will pay" + price +);
		
		}
		}
			
			
		}
		

	}

}
