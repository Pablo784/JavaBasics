
public class WhileFor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i=1; i<=5; i++) {
			System.out.println("i:" + 1);
		}
		int j=1;
		while (j<=10) {
			System.out.println("j: "+ j);
			j = j+1;
		}
	}

}
