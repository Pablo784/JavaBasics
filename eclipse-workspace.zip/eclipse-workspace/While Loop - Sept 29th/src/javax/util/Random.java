import javax.swing.JOptionPane;

public class Random {

	int groceryitems; {

	groceryitems = Integer.parseInt(JOptionPane.showInputDialog("Enter cost of items"));
	
	if (groceryitems == 6 && 10 && 40 && 70 && 30 && 100) {
		JOptionPane.showMessageDialog(null, "6 items can be bought - highest price is: 70 - be aware that 100 makes you go overboard");
	if (groceryitems == 80 && 90 && 12 && 19) {
		JOptionPane.showMessageDialog(null, "3 items can be bought - highest price is: 90 - realize that 19 makes you go over your budget");  
		
	}
		
	}
	
}
}