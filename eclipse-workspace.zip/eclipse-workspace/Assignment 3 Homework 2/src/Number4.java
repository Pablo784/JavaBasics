import javax.swing.JOptionPane;
public class Number4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double cost = 0;
		String str = JOptionPane.showInputDialog("Enter the quantity in lbs");
		double weight = Double.parseDouble(str);
		String shippingType = JOptionPane.showInputDialog("Is your parcel international or domestic? ");

//		        a) package under 5 lbs and international - $30
		if (weight < 5 && shippingType.equals("international")) {
		    cost = 30;
		    //        b) package under 5 lbs and domestic - $22
		} else if (weight < 5 && shippingType.equals("domestic")) {
		    cost = 22;
		    
		    // c) package between 5 & 15 and international - $40
		    if (5 < weight && weight < 15 && shippingType.equals("international")) {
		    	cost = 40;
		    	// d) package between 5 & 15 and domestic - $32
		   } else if (5 < weight && weight < 15 && shippingType.equals("domestic")) {
			   
			   // e) package over 15 and international - $5 per pound
			   if (weight > 15 && shippingType.equals("international")) {
				   
				   // f) package over 15 and domestic - $4 per pound 
			  } else if (weight > 15 && shippingType.equals("domestic")) { 
				  
			   }
			   
		   }
		    }
		}
		

	}

//  I got help from a tutor on the CST Tutoring Slack Channel. Credit goes to that tutor

