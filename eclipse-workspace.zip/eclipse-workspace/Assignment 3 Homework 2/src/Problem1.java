import javax.swing.JOptionPane;

public class Problem1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// NY - New York, WI - Wisconsin, CA - CALIFORNIA, CT - CONNECTICUT , FL - FLORIDA
		
		
		
		int states; 
		states = Integer.parseInt(JOptionPane.showInputDialog("Enter a number between 1 and 5 to get a state abbreviation with it's full name "));
		
		switch(states) {
		
		case 1: 
			JOptionPane.showMessageDialog(null, "NY. New York"); break;
		case 2: 
			JOptionPane.showMessageDialog(null, "WI. Wisconsin"); break;
		case 3: 
			JOptionPane.showMessageDialog(null, "CA. California"); break;
		case 4: 
			JOptionPane.showMessageDialog(null, "CT. Connecticut."); break;
		case 5: 
			JOptionPane.showMessageDialog(null, "FL. Florida."); break;
		default: 
			JOptionPane.showMessageDialog(null, "The input you have typed is invalid!"); break;
			}
		
		}

	 {

	}

	}


