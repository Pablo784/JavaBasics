import javax.swing.JOptionPane;

public class Number2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int x; // number of seniors
	int y; // number of children
	int z; // number of others
	int amountdueforgroup;
	double amountdueforgrouponfriday; 
	String inputString;
	String inputString2;
	String inputString3;
	
	
	// System.out.print("Hello World");	
	inputString = JOptionPane.showInputDialog("Plase type the number of seniors:");
	x = Integer.parseInt(inputString); 
	
	inputString2 = JOptionPane.showInputDialog("Please type the number of children");
	y = Integer.parseInt(inputString2);
	
	inputString3 = JOptionPane.showInputDialog("Please type the number of others");
	z = Integer.parseInt(inputString3);
	
	amountdueforgroup = x * 6 + y * 4 + z * 8;
	System.out.println("Amount due for group" + amountdueforgroup);
	
	amountdueforgrouponfriday = amountdueforgroup * 0.1;
	System.out.println("Amount due for group on Friday" + amountdueforgrouponfriday);
	
	// I got help from a tutor on the CST Tutoring Slack Channel. Credit goes to that tutor.
	
	}

}
