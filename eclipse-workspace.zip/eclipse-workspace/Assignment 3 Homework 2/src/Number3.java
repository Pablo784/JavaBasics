import javax.swing.JOptionPane;
public class Number3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int hours;
		String str;	    
	    // ask user to enter the number of hours
	    str = JOptionPane.showInputDialog("Enter the number of hours you worked this week ");
	    // parsing string into integer
	   hours = Integer.parseInt(str);
	   
	   double rate;
		String rte;	    
	    // ask user to enter the rate
	    rte = JOptionPane.showInputDialog("Enter the hourly rate ");
	    // parsing string into double
	   rate = Double.parseDouble(rte);
	   
	   double total = 0;
	   if (hours > 40) {
		    int overtime = hours - 40;
		    total = 40 * rate + overtime * rate * 1.5;
		} else {
		    total = hours * rate;
		}
		JOptionPane.showMessageDialog(null, total);
		}
	}
// I got help from a tutor on the CST Tutoring Slack Channel. Credit goes to that tutor
