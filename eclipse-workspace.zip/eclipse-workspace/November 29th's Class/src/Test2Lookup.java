import javax.swing.JOptionPane;
public class Test2Lookup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		String[] colleges = {"Baruch","CityTech","Hunter","Brooklyn","BMCC"}; 
		
		String[] colors = {"Blue","Red","Green","Yellow","Purple"};
		String incollege;
		incollege = JOptionPane.showInputDialog("Enter College:");
		boolean found = false;
		for (int i = 0; i<colleges.length;i++) {
			if (incollege.equals(colleges[i])) {
				System.out.println(colors[i]);
				found=true;
				break;
			} 
			
		}
		if(found==false) {System.out.println("UNKNOWN");}
	}

}
