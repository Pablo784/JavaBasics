
public class Test2Temperature {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] low = {10,13,32,44,59,62,64,63,54,49,30,22}; 
		int[] high = {30,43,52,64,79,82,74,73,84,79,80,42};
		
		int maxdiff=0; // tells me the biggest dif so far
		int maxindex=0; // what index holds the biggest diff
		
		for (int i = 0; i<low.length;i++) {
			int diff = high[i]-low[i];
			if(diff>maxdiff) {
				maxdiff=diff;
				maxindex = i;
				
			}
		}
		
		
	}

}
